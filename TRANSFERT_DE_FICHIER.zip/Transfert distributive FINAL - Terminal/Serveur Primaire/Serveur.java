import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

public class Serveur {
    private static int PORT;
    private static String LOG_PATH;
    private static String TEMP_PATH;
    private static String FILES_PATH;

    public static String getLOG_PATH() {
        return LOG_PATH;
    }

    public static String getTEMP_PATH() {
        return TEMP_PATH;
    }

    public static String getFILES_PATH() {
        return FILES_PATH;
    }

    private static List<String> secondaryServerAddresses = new ArrayList<>();

    public Serveur() {
        loadConfiguration();
    }

    private void loadConfiguration() {
        Properties properties = new Properties();
        try (InputStream input = new FileInputStream("conf/config.properties")) {
            properties.load(input);
            PORT = Integer.parseInt(properties.getProperty("PORT"));
            LOG_PATH = properties.getProperty("LOG_PATH");
            TEMP_PATH = properties.getProperty("TEMP_PATH");
            FILES_PATH = properties.getProperty("FILES_PATH");
            String servers = properties.getProperty("SECONDARY_SERVERS");
            if (servers != null) {
                secondaryServerAddresses = Arrays.asList(servers.split(","));
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Erreur de chargement de la configuration. Utilisation des valeurs par defaut.");
            PORT = 9090;
            LOG_PATH = "log/";
        }
    }

    private void log(String message) {
        File dir = new File(LOG_PATH);
        if (!dir.exists())
            dir.mkdir();
        try (BufferedWriter logWriter = new BufferedWriter(new FileWriter(LOG_PATH + "server.log", true))) {
            logWriter.write(LocalDateTime.now() + " - " + message);
            logWriter.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private List<String> detectActiveServers() {
        List<String> activeServers = new ArrayList<>();
        for (String server : secondaryServerAddresses) {
            String[] parts = server.split(":");
            String address = parts[0];
            int port = Integer.parseInt(parts[1]);

            try (Socket socket = new Socket(address, port);
                    DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                    DataInputStream dis = new DataInputStream(socket.getInputStream())) {

                dos.writeUTF("PING");
                String response = dis.readUTF();
                if ("PONG".equals(response)) {
                    activeServers.add(server);
                }
            } catch (IOException e) {
                log("Serveur inactif : " + server);
            }
        }
        log("Serveurs secondaires actifs detectes : " + activeServers);
        return activeServers;
    }

    // ======================================>>> UPLOAD

    private boolean sendPartToServer(File partFile, String address, int port) {
        try (Socket socket = new Socket(address, port);
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                FileInputStream fis = new FileInputStream(partFile)) {

            dos.writeUTF("UPLOAD_PART");
            dos.writeUTF(partFile.getName());
            dos.writeLong(partFile.length());

            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                dos.write(buffer, 0, bytesRead);
            }
            return true;

        } catch (IOException e) {
            log("Erreur d'envoi a " + address + ": " + e.getMessage());
            return false;
        }
    }

    public void splitAndDistributeFile(File inputFile) throws IOException {
        List<String> activeServers = detectActiveServers();
        int numPartitions = activeServers.size();
        if (numPartitions == 0) {
            log("Aucun serveur secondaire actif.");
            throw new IOException("Pas de serveurs secondaires disponibles.");
        }

        File dir = new File(TEMP_PATH);
        if (!dir.exists())
            dir.mkdir();

        try (FileInputStream fis = new FileInputStream(inputFile)) {
            long fileSize = inputFile.length();
            long partSize = fileSize / numPartitions;
            long remainingBytes = fileSize % numPartitions;

            List<File> partFiles = new ArrayList<>();
            for (int i = 0; i < numPartitions; i++) {
                long currentPartSize = (i == numPartitions - 1) ? partSize + remainingBytes : partSize;
                File partFile = new File(TEMP_PATH + inputFile.getName() + ".part" + (i + 1));
                try (FileOutputStream fos = new FileOutputStream(partFile)) {
                    byte[] buffer = new byte[1024];
                    long bytesWritten = 0;
                    int bytesRead;
                    while (bytesWritten < currentPartSize && (bytesRead = fis.read(buffer)) != -1) {
                        fos.write(buffer, 0, bytesRead);
                        bytesWritten += bytesRead;
                    }
                }
                partFiles.add(partFile);
            }

            try {
                for (int i = 0; i < numPartitions; i++) {
                    String server = activeServers.get(i);
                    String[] parts = server.split(":");
                    String address = parts[0];
                    int port = Integer.parseInt(parts[1]);

                    if (sendPartToServer(partFiles.get(i), address, port)) {

                        log("Partie envoyee avec succes a: " + server);
                    } else {
                        log("Echec d'envoi de la partie a: " + server);
                    }
                }
                fileUploadSuccess(inputFile.getName() + " -------------->> Upload reussi, taille : " + fileSize
                        + " octets  partition : " + numPartitions);
                inputFile.delete();
                deleteTempDirectory();
                dir.delete();
            } catch (Exception e) {
                System.out.println("Erreur lors de l upload : " + e.getMessage());
            }

        }
    }

    private static void fileUploadSuccess(String message) {
        File dir = new File(FILES_PATH);
        if (!dir.exists())
            dir.mkdir();
        try (BufferedWriter logWriter = new BufferedWriter(new FileWriter(FILES_PATH + "file.success", true))) {
            logWriter.write(message);
            logWriter.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void deleteTempDirectory() {
        File tempDir = new File(TEMP_PATH);
        if (tempDir.exists() && tempDir.isDirectory()) {
            File[] files = tempDir.listFiles();
            if (files != null) {
                for (File file : files) {
                    file.delete();
                }
            }
        }
    }

    // ===============================================>>> DOWNLOAD

    private boolean downloadPartFromServer(String partName, String address, int port) {
        try (Socket socket = new Socket(address, port);
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                DataInputStream dis = new DataInputStream(socket.getInputStream())) {

            // Envoyer la commande de telechargement
            dos.writeUTF("DOWNLOAD_PART");
            dos.writeUTF(partName);

            // Lire la reponse du serveur secondaire
            long partSize = dis.readLong();
            if (partSize == -1) {
                log("Erreur : La partition " + partName + " est manquante sur " + address + ":" + port);
                return false; // La partition n'existe pas sur ce serveur secondaire
            }

            // Telecharger la partition si elle est disponible
            File partFile = new File(TEMP_PATH + partName);
            try (FileOutputStream fos = new FileOutputStream(partFile)) {
                byte[] buffer = new byte[1024];
                int bytesRead;
                long totalRead = 0;

                while (totalRead < partSize && (bytesRead = dis.read(buffer)) != -1) {
                    fos.write(buffer, 0, bytesRead);
                    totalRead += bytesRead;
                }
            }
            log("Partition " + partName + " telechargee avec succes depuis " + address + ":" + port);
            return true;

        } catch (IOException e) {
            log("Erreur lors du telechargement de " + partName + " depuis " + address + ":" + port + ": "
                    + e.getMessage());
            return false; // echec du telechargement en raison d'une erreur
        }
    }

    public boolean fetchPartitions(String fileName, int numPartitions) {
        List<String> activeServers = detectActiveServers();
        if (activeServers.isEmpty()) {
            log("Aucun serveur secondaire actif.");
            return false;
        }

        for (int i = 1; i <= numPartitions; i++) {
            String partName = fileName + ".part" + i;
            boolean partFetched = false;

            log("Recherche de la partition : " + partName);
            for (String server : activeServers) {
                String[] parts = server.split(":");
                String address = parts[0];
                int port = Integer.parseInt(parts[1]);

                log("Tentative de telechargement depuis " + address + ":" + port);
                if (downloadPartFromServer(partName, address, port)) {
                    log("Partition " + partName + " telechargee avec succes depuis " + address + ":" + port);
                    partFetched = true;
                    break;
                } else {
                    log("Partition " + partName + " introuvable sur " + address + ":" + port);
                }
            }

            if (!partFetched) {
                log("Impossible de recuperer la partition : " + partName);
                return false; // echec si une partition est introuvable
            }
        }

        return true; // Toutes les partitions ont ete recuperees avec succes
    }

    public int getFilePartitionCount(String fileName) {
        File file = new File(FILES_PATH + "file.success");
        if (!file.exists()) {
            log("Le fichier file.success est introuvable.");
            return -1;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith(fileName)) {
                    int partitionIndex = line.lastIndexOf("partition : ");
                    if (partitionIndex != -1) {
                        return Integer.parseInt(line.substring(partitionIndex + 12));
                    }
                }
            }
        } catch (IOException e) {
            log("Erreur lors de la lecture de file.success : " + e.getMessage());
        }

        log("Le fichier " + fileName + " est introuvable dans file.success.");
        return -1;
    }

    public void sendMergedFile(DataOutputStream dos, String fileName) throws IOException {
        List<File> partFiles = new ArrayList<>();
        File dir = new File(TEMP_PATH);
        if (!dir.exists())
            dir.mkdir();

        for (int i = 1;; i++) {
            File partFile = new File(dir, fileName + ".part" + i);
            if (!partFile.exists())
                break;
            partFiles.add(partFile);
        }

        if (partFiles.isEmpty()) {
            dos.writeUTF("Erreur : Partitions introuvables pour " + fileName);
            log("Erreur : Aucune partition disponible pour " + fileName);
            return;
        }

        partFiles.sort(Comparator.comparing(File::getName));
        File mergedFile = new File(TEMP_PATH + fileName);
        try (FileOutputStream fos = new FileOutputStream(mergedFile)) {
            for (File partFile : partFiles) {
                try (FileInputStream fis = new FileInputStream(partFile)) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    while ((bytesRead = fis.read(buffer)) != -1) {
                        fos.write(buffer, 0, bytesRead);
                    }
                }
            }
        }

        dos.writeUTF("Fichier pret pour telechargement.");
        dos.writeLong(mergedFile.length());
        try (FileInputStream fis = new FileInputStream(mergedFile)) {
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                dos.write(buffer, 0, bytesRead);
            }
        }

        log("Fichier fusionne envoye avec succes : " + fileName);
        deleteDTempDirectory();
    }

    // ===============================================>>> DELETE

    public boolean deleteFile(String fileName) {
        // Supprimer les partitions du fichier dans les serveurs secondaires
        List<String> activeServers = detectActiveServers();
        for (String server : activeServers) {
            String[] parts = server.split(":");
            String address = parts[0];
            int port = Integer.parseInt(parts[1]);

            try (Socket socket = new Socket(address, port);
                    DataOutputStream dos = new DataOutputStream(socket.getOutputStream())) {

                dos.writeUTF("DELETE_PARTS");
                dos.writeUTF(fileName);

            } catch (IOException e) {
                log("Erreur lors de la suppression des partitions pour " + fileName + " sur " + address + ":" + port);
            }
        }

        // Supprimer l'entree dans file.success
        File fileSuccess = new File(FILES_PATH + "file.success");
        if (!fileSuccess.exists()) {
            log("Le fichier file.success est introuvable.");
            return false;
        }

        List<String> lines = new ArrayList<>();
        boolean fileDeleted = false;

        try (BufferedReader reader = new BufferedReader(new FileReader(fileSuccess))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.startsWith(fileName)) {
                    lines.add(line);
                } else {
                    fileDeleted = true;
                }
            }
        } catch (IOException e) {
            log("Erreur lors de la lecture de file.success : " + e.getMessage());
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileSuccess))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            log("Erreur lors de la mise à jour de file.success : " + e.getMessage());
        }

        if (fileDeleted) {
            log("Le fichier " + fileName + " a ete supprime avec succes.");
        } else {
            log("Le fichier " + fileName + " etait introuvable dans file.success.");
        }

        return fileDeleted;
    }

    public void deleteDTempDirectory() {
        File tempDir = new File(TEMP_PATH);
        if (tempDir.exists() && tempDir.isDirectory()) {
            File[] files = tempDir.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isFile()) {
                        file.delete();
                    }
                }
            }
            tempDir.delete();
        }
        log("Dossier temporaire supprime : " + TEMP_PATH);
    }

    public static void main(String[] args) {
        Serveur serveur = new Serveur();
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Serveur en attente de connexions sur le port : " + PORT + "...");
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Client connecte : " + socket.getInetAddress());
                serveur.log("Client connecte : " + socket.getInetAddress());
                new ClientHandler(socket, serveur).start();
            }
        } catch (IOException e) {
            serveur.log("Erreur : " + e.getMessage());
            e.printStackTrace();
        }
    }
}

class ClientHandler extends Thread {
    private Socket socket;
    private Serveur serveur;

    public ClientHandler(Socket socket, Serveur serveur) {
        this.socket = socket;
        this.serveur = serveur;
    }

    private void handleUpload(DataInputStream dis, DataOutputStream dos) throws IOException {
        String fileName = dis.readUTF();
        long fileSize = dis.readLong();
        File dir = new File(Serveur.getTEMP_PATH());
        if (!dir.exists())
            dir.mkdir();
        File inputFile = new File(dir, fileName);

        try (FileOutputStream fos = new FileOutputStream(inputFile)) {
            byte[] buffer = new byte[1024];
            long totalRead = 0;
            int bytesRead;
            while (totalRead < fileSize && (bytesRead = dis.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
                totalRead += bytesRead;
            }
        }
        serveur.splitAndDistributeFile(inputFile);
        inputFile.delete();
        dir.delete();
        dos.writeUTF("Fichier envoye avec succes.");

    }

    private void handleDownload(DataInputStream dis, DataOutputStream dos) throws IOException {
        File dir = new File(Serveur.getTEMP_PATH());
        if (!dir.exists())
            dir.mkdir();
        String fileName = dis.readUTF();
        int numPartitions = serveur.getFilePartitionCount(fileName);
        System.out.println("nombre partition est : " + numPartitions);

        if (numPartitions <= 0) {
            dos.writeUTF("Erreur : Informations sur le fichier introuvables.");
            serveur.deleteDTempDirectory();
            return;
        }

        boolean allPartitionsFetched = serveur.fetchPartitions(fileName, numPartitions);

        if (!allPartitionsFetched) {
            dos.writeUTF("Erreur : Impossible de recuperer toutes les partitions.");
            serveur.deleteDTempDirectory();;
            return;
        }

        serveur.sendMergedFile(dos, fileName);
        serveur.deleteDTempDirectory();
    }

    private void handleDelete(DataInputStream dis, DataOutputStream dos) throws IOException {
        String fileName = dis.readUTF();
        if (serveur.deleteFile(fileName)) {
            dos.writeUTF("Fichier supprime avec succes.");
        } else {
            dos.writeUTF("Erreur : Le fichier n'a pas pu etre supprime.");
        }
    }

    @Override
    public void run() {
        try (DataInputStream dis = new DataInputStream(socket.getInputStream());
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream())) {

            String command;

            while (true) {
                command = dis.readUTF();
                if ("QUIT".equalsIgnoreCase(command)) {
                    System.out.println("Client deconnecte : " + socket.getInetAddress());
                    dos.writeUTF("Deconnexion...");
                    break;
                }

                switch (command.toUpperCase()) {
                    case "UPLOAD" -> {
                        handleUpload(dis, dos);
                    }
                    case "DOWNLOAD" -> {
                        handleDownload(dis, dos);
                    }
                    case "DELETE" -> {
                        handleDelete(dis, dos);
                    }
                    case "LIST_FILES" -> {
                        sendFileList(dos);
                    }

                    default -> dos.writeUTF("Commande inconnue : " + command);

                }
            }

        } catch (IOException e) {
            log("Erreur : " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void sendFileList(DataOutputStream dos) throws IOException {
        String filePath = Serveur.getFILES_PATH() + "file.success";
        File file = new File(filePath);
        if (!file.exists() || file.length() == 0) {
            log("Aucun fichier disponible");
            dos.writeInt(0); // Aucun fichier disponible
        } else {
            Set<String> uniqueLines = new HashSet<>();
            try (BufferedReader filReader = new BufferedReader(new FileReader(filePath))) {
                String line;
                while ((line = filReader.readLine()) != null) {
                    uniqueLines.add(line);
                }
            }
            String[] lines = uniqueLines.toArray(new String[0]);
            if (lines != null) {
                for (int i = 0; i < lines.length; i++) {
                    int index = lines[i].indexOf(" -------------->> Upload reussi, taille : ");
                    if (index != -1) {
                        lines[i] = lines[i].substring(0, index);
                    }
                }

                dos.writeInt(lines.length);
                for (String filename : lines) {
                    dos.writeUTF(filename);
                }
                log("Liste des fichiers envoye avec succes");
            } else {
                log("Aucun fichier disponible");
                dos.writeInt(0); // Aucun fichier disponible
            }
        }
    }

    private void log(String message) {
        File dir = new File(Serveur.getLOG_PATH());
        if (!dir.exists())
            dir.mkdir();
        try (BufferedWriter logWriter = new BufferedWriter(new FileWriter(Serveur.getLOG_PATH() + "action.log", true))) {
            logWriter.write(LocalDateTime.now() + " - " + message);
            logWriter.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
