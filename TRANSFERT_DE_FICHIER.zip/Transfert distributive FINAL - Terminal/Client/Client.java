import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    private static final String SERVER_ADDRESS = "127.0.0.1";
    private static final int PORT = 9090;

    public static void main(String[] args) {
        System.out.println("Connexion au serveur ...");

        try (Socket socket = new Socket(SERVER_ADDRESS, PORT);
             DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
             DataInputStream dis = new DataInputStream(socket.getInputStream());
             Scanner scanner = new Scanner(System.in)) {

            System.out.println("Connexion reussie. Tapez \"help\" pour voir les commandes.");

            while (true) {
                System.out.print("transfert> ");
                String command = scanner.nextLine().trim();

                if (command.equalsIgnoreCase("quit")) {
                    dos.writeUTF("QUIT");
                    System.out.println("Deconnexion...");
                    break;
                }

                String[] parts = command.split(" ", 2);
                String action = parts[0].toLowerCase();

                switch (action) {
                    case "put" -> {
                        if (parts.length < 2) {
                            System.out.println("Usage: upload <chemin_du_fichier>");
                        } else {
                            uploadFile(parts[1], dos, dis);
                        }
                    }
                    case "get" -> {
                        if (parts.length < 2) {
                            System.out.println("Usage: download <nom_du_fichier>");
                        } else {
                            downloadFile(parts[1], dos, dis);
                        }
                    }
                    case "del" -> {
                        if (parts.length < 2) {
                            System.out.println("Usage: delete <nom_du_fichier>");
                        } else {
                            deleteFile(parts[1], dos, dis);
                        }
                    }
                    case "ls" -> listFiles(dos, dis);
                    case "help" -> printHelp();
                    default -> System.out.println("Commande inconnue. Tapez \"help\" pour voir les commandes.");
                }
            }
        } catch (IOException e) {
            System.out.println("Erreur de connexion au serveur : " + e.getMessage());
        }
    }

    private static void printProgressBar(long current, long total) {
        int barLength = 50; // longueur total de la barre
        double progress = (double) current / total;
        int filledLength = (int) (progress * barLength);

        StringBuilder bar = new StringBuilder();
        for (int i = 0; i < filledLength; i++) {
            bar.append("#"); // partie remplie
        }
        for (int i = filledLength; i < barLength; i++) {
            bar.append("-"); // Partie vide
        }

        System.out.print("\r[" + bar + "]  " + (int) (progress * 100) + "%");
    }

    private static void uploadFile(String filePath, DataOutputStream dos, DataInputStream dis) throws IOException {
        File file = new File(filePath);
        if (!file.exists() || !file.isFile()) {
            System.out.println("Fichier introuvable.");
            return;
        }
        long filesize = file.length();

        try (FileInputStream fis = new FileInputStream(file)) {
            dos.writeUTF("UPLOAD");
            dos.writeUTF(file.getName());
            dos.writeLong(file.length());

            byte[] buffer = new byte[1024];
            int bytesRead;
            long byteCopied = 0;

            while ((bytesRead = fis.read(buffer)) != -1) {
                dos.write(buffer, 0, bytesRead);
                byteCopied += bytesRead;

                printProgressBar(byteCopied, filesize);
            }
            System.out.println("\n"+dis.readUTF());
        } catch (IOException e) {
            System.out.println("Erreur lors de l'envoi : " + e.getMessage());
        }
    }

    private static void downloadFile(String fileName, DataOutputStream dos, DataInputStream dis) {
        try {
            dos.writeUTF("DOWNLOAD");
            dos.writeUTF(fileName);

            String response = dis.readUTF();
            if (response.startsWith("Erreur")) {
                System.out.println(response);
                return;
            }

            long fileSize = dis.readLong();
            File outputFile = new File("DOWNLOADS/" + fileName);
            outputFile.getParentFile().mkdirs();

            try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                byte[] buffer = new byte[1024];
                int bytesRead;
                long totalRead = 0;

                while (totalRead < fileSize && (bytesRead = dis.read(buffer)) != -1) {
                    fos.write(buffer, 0, bytesRead);
                    totalRead += bytesRead;
                    printProgressBar(totalRead, fileSize);
                }
            }
            System.out.println("\nFichier telecharge avec succes : " + fileName);
        } catch (IOException e) {
            System.out.println("\nErreur de telechargement : " + e.getMessage());
        }
    }

    private static void deleteFile(String fileName, DataOutputStream dos, DataInputStream dis) {
        try {
            dos.writeUTF("DELETE");
            dos.writeUTF(fileName);
            System.out.println(dis.readUTF());
        } catch (IOException e) {
            System.out.println("Erreur de suppression : " + e.getMessage());
        }
    }

    private static void listFiles(DataOutputStream dos, DataInputStream dis) {
        try {
            dos.writeUTF("LIST_FILES");
            int fileCount = dis.readInt();

            if (fileCount == 0) {
                System.out.println("Aucun fichier disponible.");
                return;
            }

            System.out.println("Fichiers disponibles :");
            for (int i = 0; i < fileCount; i++) {
                System.out.println(" -  " + dis.readUTF());
            }
        } catch (IOException e) {
            System.out.println("Erreur lors de la liste des fichiers : " + e.getMessage());
        }
    }

    private static void printHelp() {
        System.out.println("""
                Commandes disponibles :
                - put <chemin_du_fichier> : Envoyer un fichier.
                - get <nom_du_fichier> : Telecharger un fichier.
                - del <nom_du_fichier> : Supprimer un fichier.
                - ls : Lister les fichiers.
                - quit : Quitter.
                - help : Afficher ce menu.
                """);
    }
}

