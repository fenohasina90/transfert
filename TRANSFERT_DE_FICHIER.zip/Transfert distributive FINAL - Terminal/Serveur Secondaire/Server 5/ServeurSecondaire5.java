import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.LocalDateTime;
import java.util.Properties;

public class ServeurSecondaire5 {
    private static int PORT;
    private static String STORAGE_DIR;
    private static String LOG_PATH;

    public ServeurSecondaire5 () {
        loadConfiguration();
    }

    private void loadConfiguration() {
        Properties properties = new Properties();
        try (InputStream input = new FileInputStream("conf/config.properties")) {
            properties.load(input);
            PORT = Integer.parseInt(properties.getProperty("PORT"));
            STORAGE_DIR = properties.getProperty("STORAGE_DIR");
            LOG_PATH = properties.getProperty("LOG_PATH");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Erreur de chargement de la configuration. Utilisation des valeurs par defaut.");
            PORT = 9095;
            STORAGE_DIR = "SAVE/";
            LOG_PATH = "log/";
        }
    }

    public static void main(String[] args) {
        new ServeurSecondaire5();
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Serveur secondaire 5 en attente...");
            while (true) {
                Socket socket = serverSocket.accept();
                new Thread(() -> handleClient(socket)).start();
                // System.out.println(socket.getInetAddress() + " est connecte");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void handleClient(Socket socket) {
        File dir = new File(STORAGE_DIR);
        if (!dir.exists())
            dir.mkdir();
        try (DataInputStream dis = new DataInputStream(socket.getInputStream());
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream())) {

            String command = dis.readUTF();

            if (command.equals("PING")) {
                dos.writeUTF("PONG");

            }else if (command.equals("UPLOAD_PART")) {
                String partName = dis.readUTF();
                long partSize = dis.readLong();
                File partFile = new File(STORAGE_DIR + partName);

                try (FileOutputStream fos = new FileOutputStream(partFile)) {
                    byte[] buffer = new byte[1024];
                    int bytesRead;
                    long totalRead = 0;
                    while (totalRead < partSize && (bytesRead = dis.read(buffer)) != -1) {
                        fos.write(buffer, 0, bytesRead);
                        totalRead += bytesRead;
                    }
                    System.out.println("Partie reçue : " + partName);
                    dos.writeUTF("Partie reçue : " + partName);
                    log("Partie reçue : " + partName);

                } catch (IOException e) {
                    System.out.println("Erreur d'enregistrement : " + e.getMessage());
                    dos.writeUTF("Erreur d'enregistrement : " + e.getMessage());
                    log("Erreur d'enregistrement : " + e.getMessage());
                }
            }
            else if (command.equals("DOWNLOAD_PART")) {
                String partName = dis.readUTF();
                File partFile = new File(STORAGE_DIR + partName);
            
                if (partFile.exists()) {
                    dos.writeLong(partFile.length()); // Envoyer la taille du fichier
                    try (FileInputStream fis = new FileInputStream(partFile)) {
                        byte[] buffer = new byte[1024];
                        int bytesRead;
                        while ((bytesRead = fis.read(buffer)) != -1) {
                            dos.write(buffer, 0, bytesRead);
                        }
                    }
                    log("Partition envoyee au serveur principal : " + partName);
                } else {
                    dos.writeLong(-1); // Indiquer que le fichier n'existe pas
                    log("Erreur : Partition manquante - " + partName);
                }
            }else if (command.equals("DELETE_PARTS")) {
                String fileName = dis.readUTF();
            
                if (dir.exists() && dir.isDirectory()) {
                    File[] files = dir.listFiles();
                    if (files != null) {
                        for (File file : files) {
                            if (file.getName().startsWith(fileName)) {
                                if (file.delete()) {
                                    log("Partition supprimee : " + file.getName());
                                } else {
                                    log("Erreur lors de la suppression de la partition : " + file.getName());
                                }
                            }
                        }
                    }
                }
            }

        } catch (IOException e) {
            log("Erreur : " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void log(String message) {
        File dir = new File(LOG_PATH);
        if (!dir.exists())
            dir.mkdir();
        try (BufferedWriter logWriter = new BufferedWriter(new FileWriter(LOG_PATH + "server.log", true))) {
            logWriter.write(LocalDateTime.now() + " - " + message);
            logWriter.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
