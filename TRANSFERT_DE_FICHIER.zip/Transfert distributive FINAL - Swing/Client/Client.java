import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;
import java.time.LocalDateTime;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class Client extends JFrame {
    private JButton uploadButton;
    private JButton downloadButton;
    private JProgressBar progressBar;
    private JTextArea logArea;
    private File selectedFile; // Stocke le fichier selectionne
    private JComboBox<String> fileDropdown;
    private JButton listFilesButton;
    private JButton deletefile;

    private static final String SERVER_ADDRESS = "127.0.0.1";
    private static final int PORT = 9090;

    public Client() {
        setTitle("Client de Transfert de Fichiers");
        setSize(1200, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initializeComponents();
        loadFileList();
    }

    private void initializeComponents() {
        uploadButton = new JButton("Envoyer un fichier");
        progressBar = new JProgressBar();
        downloadButton = new JButton("Telecharger un fichier");
        progressBar.setStringPainted(true);
        Color c = new Color(100, 100, 152);
        progressBar.setBackground(c);
        logArea = new JTextArea(10, 40);
        logArea.setEditable(false);
        fileDropdown = new JComboBox<>();
        listFilesButton = new JButton("Liste des fichiers");
        deletefile = new JButton("Supprimer un fichier");
        
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        panel.add(uploadButton);
        panel.add(downloadButton);
        panel.add(progressBar);
        panel.add(listFilesButton);
        panel.add(deletefile);
        
        deletefile.addActionListener(new DeleteAction());
        listFilesButton.addActionListener(new ListFilesAction());
        uploadButton.addActionListener(new UploadAction());
        downloadButton.addActionListener(new DownloadAction());

        add(panel, BorderLayout.NORTH);
        add(new JScrollPane(logArea), BorderLayout.CENTER);
    }

    private void loadFileList() {
        try (Socket socket = new Socket(SERVER_ADDRESS, PORT);
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                DataInputStream dis = new DataInputStream(socket.getInputStream())) {

            dos.writeUTF("LIST_FILES");
            int fileCount = dis.readInt();
            fileDropdown.removeAllItems(); // Nettoie la liste actuelle

            for (int i = 0; i < fileCount; i++) {
                fileDropdown.addItem(dis.readUTF()); // Ajoute chaque fichier a la liste
            }
        } catch (IOException ex) {
            log("Erreur lors du chargement des fichiers : " + ex.getMessage());
        }
    }

    private class ListFilesAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            loadFileList(); // Charger la liste des fichiers
            if (fileDropdown.getItemCount() > 0) {
                // Affiche les fichiers dans une boîte de dialogue
                JPanel filePanel = new JPanel();
                filePanel.setLayout(new BoxLayout(filePanel, BoxLayout.Y_AXIS));

                for (int i = 0; i < fileDropdown.getItemCount(); i++) {
                    String fileName = fileDropdown.getItemAt(i);
                    JButton deleteButton = new JButton("Supprimer");
                    JButton DownButton = new JButton("Telecharger");
                    JLabel fileLabel = new JLabel(fileName);

                    deleteButton.addActionListener(event -> {
                        int confirmation = JOptionPane.showConfirmDialog(
                                null,
                                "Voulez-vous supprimer " + fileName + "?",
                                "Confirmation de suppression",
                                JOptionPane.YES_NO_OPTION);

                        if (confirmation == JOptionPane.YES_OPTION) {
                            new Thread(() -> deleteFile(fileName)).start();
                            log(fileName+" est supprime");
                            loadFileList();
                        }
                    });

                    DownButton.addActionListener(event -> {
                        new Thread(() -> downloadFile(fileName)).start();
                    });

                    JPanel itemPanel = new JPanel();
                    itemPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
                    itemPanel.add(fileLabel);
                    // itemPanel.add(DownButton);
                    // itemPanel.add(deleteButton);
                    filePanel.add(itemPanel);
                }

                JOptionPane.showMessageDialog(null, filePanel, "Liste des fichiers", JOptionPane.PLAIN_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Aucun fichier disponible.");
            }
        }
    }

    private class DeleteAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            loadFileList(); // Charge les fichiers disponibles

            if (fileDropdown.getItemCount() > 0) {
                // Affiche la liste deroulante dans une boîte de dialogue
                int result = JOptionPane.showConfirmDialog(null, fileDropdown, "Selectionnez un fichier a supprimer",
                        JOptionPane.OK_CANCEL_OPTION);

                if (result == JOptionPane.OK_OPTION) {
                    String fileName = (String) fileDropdown.getSelectedItem();
                    if (fileName != null && !fileName.trim().isEmpty()) {
                        int confirmation = JOptionPane.showConfirmDialog(
                                null,
                                "Voulez-vous supprimer " + fileName + "?",
                                "Confirmation de suppression",
                                JOptionPane.YES_NO_OPTION);

                        if (confirmation == JOptionPane.YES_OPTION) {
                            new Thread(() -> deleteFile(fileName)).start();
                            loadFileList();
                            log(fileName+" est supprime");
                        }
                        // new Thread(() -> deleteFile(fileName)).start();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Aucun fichier disponible pour le telechargement.");
            }
        }
    }

    private void deleteFile(String fileName) {
        try (Socket socket = new Socket(SERVER_ADDRESS, PORT);
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                DataInputStream dis = new DataInputStream(socket.getInputStream())) {

            dos.writeUTF("DELETE");
            dos.writeUTF(fileName);

            String response = dis.readUTF();
            JOptionPane.showMessageDialog(null, response);

            // Recharge la liste des fichiers apres suppression
            loadFileList();
        } catch (IOException ex) {
            log("Erreur lors de la suppression de " + fileName + " : " + ex.getMessage());
            JOptionPane.showMessageDialog(null, "Erreur lors de la suppression : " + ex.getMessage(), "Erreur",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private class UploadAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Selectionnez un fichier a envoyer");
            int result = fileChooser.showOpenDialog(null);

            if (result == JFileChooser.APPROVE_OPTION) {
                selectedFile = fileChooser.getSelectedFile();
                log("Fichier selectionne : " + selectedFile.getAbsolutePath());

                new Thread(() -> {

                    uploadFile(selectedFile);
                    selectedFile = null;

                }).start();
            }

        }
    }

    private void uploadFile(File file) {
        try (Socket socket = new Socket(SERVER_ADDRESS, PORT);
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                DataInputStream dis = new DataInputStream(socket.getInputStream());
                FileInputStream fis = new FileInputStream(file)) {

            dos.writeUTF("UPLOAD");
            dos.writeUTF(file.getName());
            dos.writeLong(file.length());

            byte[] buffer = new byte[1024];
            int bytesRead;
            long totalRead = 0;
            while ((bytesRead = fis.read(buffer)) != -1) {
                dos.write(buffer, 0, bytesRead);
                totalRead += bytesRead;
                int progress = (int) ((totalRead * 100) / file.length());
                SwingUtilities.invokeLater(() -> progressBar.setValue(progress));
            }

            String serverResponse = dis.readUTF();
            JOptionPane.showMessageDialog(null, serverResponse);
            log(serverResponse);

        } catch (IOException ex) {
            log("Erreur d'envoi : " + ex.getMessage());
            JOptionPane.showMessageDialog(null, "Erreur d'envoi du fichier : " + ex.getMessage());
        }
    }

    
    private class DownloadAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            loadFileList(); // Charge les fichiers disponibles

            if (fileDropdown.getItemCount() > 0) {
                // Affiche la liste deroulante dans une boîte de dialogue
                int result = JOptionPane.showConfirmDialog(null, fileDropdown, "Selectionnez un fichier a telecharger",
                        JOptionPane.OK_CANCEL_OPTION);

                if (result == JOptionPane.OK_OPTION) {
                    String fileName = (String) fileDropdown.getSelectedItem();
                    if (fileName != null && !fileName.trim().isEmpty()) {
                        new Thread(() -> downloadFile(fileName)).start();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Aucun fichier disponible pour le telechargement.");
            }
        }
    }

    private void downloadFile(String fileName) {
        File dir = new File("DOWNLOADS/");
        if (!dir.exists())
            dir.mkdir();

        try (Socket socket = new Socket(SERVER_ADDRESS, PORT);
                DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                DataInputStream dis = new DataInputStream(socket.getInputStream())) {

            dos.writeUTF("DOWNLOAD");
            dos.writeUTF(fileName);

            // Verifie si le serveur renvoie un message d'erreur avant de continuer
            String response = dis.readUTF();
            if (response.startsWith("Erreur")) {
                JOptionPane.showMessageDialog(null, response, "Erreur de telechargement", JOptionPane.ERROR_MESSAGE);
                log(response);
                return;
            }

            // Le serveur a envoye le signal de debut de transfert
            long fileSize = dis.readLong();
            File outputFile = new File("DOWNLOADS/" + fileName);
            outputFile.getParentFile().mkdirs();

            try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                byte[] buffer = new byte[1024];
                int bytesRead;
                long totalRead = 0;

                while (totalRead < fileSize && (bytesRead = dis.read(buffer)) != -1) {
                    fos.write(buffer, 0, bytesRead);
                    totalRead += bytesRead;
                    int progress = (int) ((totalRead * 100) / fileSize);
                    SwingUtilities.invokeLater(() -> progressBar.setValue(progress));
                }
            }

            JOptionPane.showMessageDialog(null, "Fichier telecharge avec succes.");
            log("Fichier telecharge : " + fileName);

        } catch (IOException ex) {
            log("Erreur de telechargement : " + ex.getMessage());
            JOptionPane.showMessageDialog(null, "Erreur de telechargement : " + ex.getMessage(), "Erreur",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void log(String message) {
        File dir = new File("log/");
        if (!dir.exists())
            dir.mkdir();
        SwingUtilities.invokeLater(() -> {
            logArea.append(LocalDateTime.now() + " - " + message + "\n");
            try (BufferedWriter logWriter = new BufferedWriter(new FileWriter("log/client.log", true))) {
                logWriter.write(LocalDateTime.now() + " - " + message);
                logWriter.newLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Client clientGUI = new Client();
            clientGUI.setVisible(true);
        });
    }
}
